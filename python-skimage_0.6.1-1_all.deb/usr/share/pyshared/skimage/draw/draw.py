"""
Methods to draw on arrays.

"""

from ._draw import line, polygon, ellipse, circle
bresenham = line
